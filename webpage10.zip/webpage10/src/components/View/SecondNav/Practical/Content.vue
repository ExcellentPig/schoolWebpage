<template>
	<div>
		<div class="a">
			<div class="top">
				<span class="glyphicon glyphicon-home" style="color: white;line-height: 40px; padding-left: 10px;"></span>
				<router-link to="/allContent"><span class="mgs">网站首页</span></router-link>
				<span class="mgs">>>></span>
				<router-link to="/sefirst"><span class="mgs">实践教学</span></router-link>
			</div>
			<div class="one">
				<section class="about-more blog">
					<div class="container">
						<div class="row">
							<div class="col-md-10 col-md-offset-1">
								<div class="blog-post">
									<h3 class="h3">我院管理系学子在全国大学生物流仿真运营设计大赛（西南赛区）决赛中再获佳绩</h3>
									<p class="p">
										9月23-24日，“百蝶杯”第三届全国大学生物流仿真运营设计大赛（西南赛区）决赛在西南交通大学举行。本次大赛是由中国物流生产力促进中心主办、西南交通大学承办，上海百蝶计算机信息有限公司提供指导和技术支持的一项面向物流相关专业本科在校大学生的专业性比赛。比赛中参赛团队模拟运营一个物流配送中心，通过参与经营物流企业，了解企业真实的工作过程，将平时学习的理论知识与实际应用相结合，以培养职业素养，锻炼理论联系实际的能力。
									</p>
									<p class="p">大赛吸引了西南赛区高校西南交通大学、陆军勤务学院、重庆大学、西南科技大学等30支队伍参赛。我院管理系组织了两支代表队代表学院参赛，得到了院系领导、经管中心的高度重视和大力支持，获得了可喜的成绩。</p>
									<p class="p">管理系物流管理专业2015级学生夏立强、徐文杰、何孟秋同学组成的“挑战”代表队获得了西南赛区的一等奖，雷桂群、王鲸、曾月同学组成的“我最”代表队获得了西南赛区的二等奖。管理系任启文老师获大赛“优秀指导老师奖”。同时我院还获得了“最佳组织奖”的荣誉称号。</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/QQ%E5%9B%BE%E7%89%8720170925171604.jpg" alt="#" /></div>
									<p class="p centerp">指导教师任启文老师和参赛选手合影（从左至右依次为：管理系物流管理2015级雷桂群，曾月，王鲸，任启文老师，徐文杰，夏立强，何孟秋）</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/%E4%B8%80%E7%AD%89%E5%A5%96(4).jpg" alt="#" /></div>
									<p class="p centerp">一等奖荣誉证书</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/%E4%BA%8C%E7%AD%89%E5%A5%96(2).jpg" alt="#" /></div>
									<p class="p centerp">二等奖荣誉证书</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/%E4%BC%98%E7%A7%80%E7%BB%84%E7%BB%87%E5%A5%96.jpg" alt="#" /></div>
									<p class="p centerp">优秀组织奖荣誉证书</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/%E4%BC%98%E7%A7%80%E6%8C%87%E5%AF%BC%E6%95%99%E5%B8%88%E8%AF%81%E4%B9%A6.jpg" alt="#" /></div>
									<p class="p centerp">优秀指导教师奖证书</p>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
</template>

<script></script>

<style scoped="scoped">
.a {
	width: 100%;
	background-color: whitesmoke;
}
.top {
	width: 100%;
	height: 40px;
	background-color: #3366CC;
}
.mgs {
	color: white;
	padding-left: 5px;
}
p{
	color: #000000;
	cursor: pointer;
}
.one {
	background-color: whitesmoke;
}
.h3 {
	padding: 50px 0 50px 0;
	border-bottom: 1px solid darkblue;
}
.p {
	padding-top: 10px;
	line-height: 40px;
	font-size: 14px;
	margin: 10px;
	font-family: 'Cabin Condensed', sans-serif;
}
.pl{
	float: left;
	list-style: -moz-afar;
}
.pr{
	float: right;
}
.blog-post {
	border-bottom: 1px solid #ebebeb;
	margin-bottom: 40px;
	background-color:#F8F8F8;
	padding: 5px;
	margin-top: 10px;
}
.msg1{
	border-bottom: 1px dashed lightsalmon;
}
.msg1:last-child{
	margin-bottom: 20px;
	border-bottom: 1px solid darkblue;
	width: 100%;
}

.blog-post:last-child {
	border-bottom: none;
}

.blog .writer {
	width: 60px;
	border-radius: 50%;
	display: inline-block;
	margin-right: 15px;
}

.blog h3 {
	cursor: pointer;
	display: block;
	font-size: 18px;
	color: #017cef;
	margin-top: 10px;
}

.blog h3 span {
	font-weight: 600;
}

.blog strong {
	display: block;
	font-size: 13px;
	font-weight: 600;
	color: #a4b5c5;
}

.post-img img {
	width: 100%;
	border-radius: 5px;
}

.blog h2 {
	margin-bottom: 20px;
}

.blog .read-more {
	margin-top: 20px;
	margin-bottom: 40px;
}

.blog .read-more li {
	color: #7f90a0;
	font-weight: 600;
	text-transform: capitalize;
	font-size: 14px;
}

.blog .read-more li a {
	color: #017cef;
}

.footer hr {
	border-color: #393939;
}

.copyright li:hover {
	color: #017cef;
}

.copyright li {
	cursor: pointer;
}

.copyright p a {
	color: #9b9b9b;
}
.centerp{
	text-align: center;
}

.copyright {
	color: #9b9b9b;
	font-size: 13px;
}
@media screen and (max-width: 667px) {
	.top {
		background-color: darkcyan;
	}
}
</style>

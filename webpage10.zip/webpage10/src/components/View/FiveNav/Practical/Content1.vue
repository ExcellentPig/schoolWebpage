<template>
	<div>
		<div class="a">
			<div class="top">
				<span class="glyphicon glyphicon-home" style="color: white;line-height: 40px; padding-left: 10px;"></span>
				<router-link to="/allContent"><span class="mgs">网站首页</span></router-link>
				<span class="mgs">>>></span>
				<router-link to="/fivfirst"><span class="mgs">团学工作</span></router-link>
			</div>
			<div class="one">
				<section class="about-more blog">
					<div class="container">
						<div class="row">
							<div class="col-md-10 col-md-offset-1">
								<div class="blog-post">
									<h3 class="h3">挑起责任，唱响青春一一记管理系五月示范性团活</h3>
									<p class="p">
										为响应习近平总书记对青年发出的青年之约，传承五四精神，展现青春风采，2019年5月30日下午19：00，管理系信息管理与信息系统专业和旅游管理（本）全班学生欢聚一堂在3204教室开展了示范性团活活动。
									</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/1111(2).png" alt="#" /></div>
									<p class="p">
										活动开始，首先由主持人介绍了五四运动的相关历史和五四运动对新民主主义带来的相关影响，随着主持人的讲解，同学们仿佛也回到了那段历史中，给同学们带来极大的感触与震撼，心中的爱国之情也油然而生。接下来全体学生演唱《光荣啊，中国共青团》来表示对团和祖国的热爱。优秀团员代表的发言也带动了在场的气氛，在她真挚的发言中，我们能感受到她的那份激情与热血。
									</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/222(8).png" alt="#" /></div>
									<p class="p">
										接下来由旅游管理（本）同学带来的情景追忆《等待》，回忆了钱学森的一生，从他们深情的表演中我们能感受到先辈们为了祖国繁荣富强所做的牺牲。在视频《一百年华》中，我们感受到了祖国一路走来的艰辛，对今天祖国取得的成绩深表敬畏。大合唱《我和我的祖国》和朗诵《颂国诗》中，深情的演唱与朗诵使人热泪盈眶，我们也能感受到那份对祖国热爱的拳拳的赤子之心。
									</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/3333(5).png" alt="#" /></div>
									<p class="p">
										活动最后，全场同学起立重温入团誓词，活动接近尾声，伴随着优美的音乐，全体同学有序离场，表演人员和两班同学上台合影。
									</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/4444(2).png" alt="#" /></div>
									<p class="p">虽然此次团活已经接近尾声，但是做为当代大学生的我们更应该肩负起祖国伟大复兴的历史重任和使命。这不应该仅仅只是一种口号，更应该是一种责任，是实际行动。</p>
									<p class="p">管理系物流管理专业2015级学生夏立强、徐文杰、何孟秋同学组成的“挑战”代表队获得了西南赛区的一等奖，雷桂群、王鲸、曾月同学组成的“我最”代表队获得了西南赛区的二等奖。管理系任启文老师获大赛“优秀指导老师奖”。同时我院还获得了“最佳组织奖”的荣誉称号。</p>
									<div class="post-img"><img class="img-responsive" src="http://glx.cdutetc.cn/fileupload/images/QQ%E5%9B%BE%E7%89%8720170925171604.jpg" alt="#" /></div>
									<p class="p centerp">指导教师任启文老师和参赛选手合影（从左至右依次为：管理系物流管理2015级雷桂群，曾月，王鲸，任启文老师，徐文杰，夏立强，何孟秋）</p>
									<div class="fr">
										<p class="p pr">文/李山青</p>
										
										<p class="p pr">图/李山青</p>
										
										<p class="p pr">审/马晓娇</p>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
</template>

<script></script>

<style scoped="scoped">
.a {
	width: 100%;
	background-color: whitesmoke;
}
.top {
	width: 100%;
	height: 40px;
	background-color: #3366CC;
}
.mgs {
	color: white;
	padding-left: 5px;
}

.one {
	background-color: whitesmoke;
}
.h3 {
	padding: 50px 0 50px 0;
	border-bottom: 1px solid darkblue;
}
.p {
	padding-top: 10px;
	line-height: 25px;
	font-size: 16px;
	margin: 10px;
	font-family: 'Cabin Condensed', sans-serif;
	text-indent: 2em;
}
.p:last-child {
	border-bottom: 1px solid darkblue;
	padding-bottom: 20px;
}
.blog-post {
	border-bottom: 1px solid #ebebeb;
	margin-bottom: 40px;
	background-color:#F8F8F8;
	padding: 5px;
	margin-top: 10px;
}

.blog-post:last-child {
	border-bottom: none;
}

.blog .writer {
	width: 60px;
	border-radius: 50%;
	display: inline-block;
	margin-right: 15px;
}

.blog h3 {
	cursor: pointer;
	display: block;
	font-size: 18px;
	color: #017cef;
	margin-top: 10px;
}

.blog h3 span {
	font-weight: 600;
}

.blog strong {
	display: block;
	font-size: 13px;
	font-weight: 600;
	color: #a4b5c5;
}

.post-img img {
	width: 100%;
	border-radius: 5px;
}

.blog h2 {
	margin-bottom: 20px;
}

.blog .read-more {
	margin-top: 20px;
	margin-bottom: 40px;
}

.blog .read-more li {
	color: #7f90a0;
	font-weight: 600;
	text-transform: capitalize;
	font-size: 14px;
}

.blog .read-more li a {
	color: #017cef;
}

.footer hr {
	border-color: #393939;
}

.copyright li:hover {
	color: #017cef;
}

.copyright li {
	cursor: pointer;
}

.copyright p a {
	color: #9b9b9b;
}

.copyright {
	color: #9b9b9b;
	font-size: 13px;
}
@media screen and (max-width: 667px) {
	.top {
		background-color: darkcyan;
	}
}
</style>

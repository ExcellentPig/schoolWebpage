<template>
	<div class="allContentall">
		<Header></Header>	
	<!-- 	<Footer></Footer> -->
	</div>
</template>

<script>
import Header from './Header/Header.vue'
// import Footer from './Footer/Footer.vue'
export default {
	components:{
		Header
		// Footer
	}
}
</script>

<style>
</style>
